//*-------------------------------------------------------------------
//* Licensed Materials - Property of HCL Technologies
//*
//* HCL Commerce
//* HCL OneTest Performance
//*-------------------------------------------------------------------
//* The sample contained herein is provided to you "AS IS".
//*
//* It is provided by HCL Commerce to demonstrate the use of HCL OneTest
//* Performance with the "Emerald" store.
//* 
//* The sample includes a selected number of scenarios. It must be 
//* extended to match the function and use of your store.
//*
//*---------------------------------------------------------------------

package customcode;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.nio.charset.StandardCharsets;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.ibm.rational.test.lt.kernel.services.ITestExecutionServices;
public class PickProductLink implements com.ibm.rational.test.lt.kernel.custom.ICustomCode2 {
	public final static String regex="<a  id=\"catalogEntry.+?href=\".+?(/wcs/shop.+?)\".+?title";
	public PickProductLink() {}
	public String exec(ITestExecutionServices tes, String[] args) {
		String text = args[0];
		if ( text.length() == 0 ) {
			tes.getTestLogManager().reportMessage( "Error: Page response is empty" );
			return "-1";
		}
		String products = "";
		String result;
		int i;
		Pattern pattern = Pattern.compile( regex, Pattern.DOTALL );
		Matcher matcher = pattern.matcher( text );
		
		while ( matcher.find() ) {
			result = matcher.group(1);
			i = result.indexOf( "/wcs/shop" );
			if ( i != -1 ) {
				result = result.substring( i );
			}
			else {
				tes.getTestLogManager().reportMessage( "Error: String /wcs/shop was not found in facet: " + result );
				return "-1";
			}
			products += result + ',';
		}
		if ( products.length() == 0 ) {
			tes.getTestLogManager().reportMessage( "Error: No products found" );
			return "-1";
		}
		// Clean the last comma
		products = products.substring( 0, products.length() - 1 );
		
		// Transform the string to an array 
		String [] arr_products = products.split( "," );
		
		// Pick a random top category
		i = (int) Math.floor( Math.random() * arr_products.length );
		
		// Decode the URL
		String correctEncodedURL = "";
		try {
			correctEncodedURL = URLDecoder.decode( arr_products[ i ], StandardCharsets.UTF_8.toString() );
		} catch (UnsupportedEncodingException ex) {
			tes.getTestLogManager().reportMessage( "Error: UnsupportedEncodingException\n" + ex.getMessage() );
		}
		
		// Clean &amp; from the URL
		correctEncodedURL = correctEncodedURL.replace("&amp;", "&");
		
		tes.getTestLogManager().reportMessage( "Found " + String.valueOf( arr_products.length ) + " Products' link." );
		
		if (correctEncodedURL.isEmpty()) {
			return "-1";
		} else {
			tes.getTestLogManager().reportMessage("Product link picked = " + correctEncodedURL);
			return correctEncodedURL;
		}
	}
}
