//*-------------------------------------------------------------------
//* Licensed Materials - Property of HCL Technologies
//*
//* HCL Commerce
//* HCL OneTest Performance
//*-------------------------------------------------------------------
//* The sample contained herein is provided to you "AS IS".
//*
//* It is provided by HCL Commerce to demonstrate the use of HCL OneTest
//* Performance with the "Emerald" store.
//* 
//* The sample includes a selected number of scenarios. It must be 
//* extended to match the function and use of your store.
//*
//*---------------------------------------------------------------------

package customcode;

import java.util.Random;

import com.ibm.rational.test.lt.kernel.services.ITestExecutionServices;
public class GetRandomString implements com.ibm.rational.test.lt.kernel.custom.ICustomCode2 {
	public GetRandomString() {}
	public String exec(ITestExecutionServices tes, String[] args) {
		String[] characters = { "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", 
                "a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z"};
		Random rand = new Random();
		int min = 4, max = 15;
		int len = rand.nextInt( ( max - min ) + 1 ) + min;
		int ic;
		String str = ""; 
		for ( int i = 0; i < len; i++ ) {
			ic = rand.nextInt( characters.length - 1 );
			str += characters[ ic ];
		}
		return str;
	}
}
