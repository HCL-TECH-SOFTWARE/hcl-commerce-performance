//*-------------------------------------------------------------------
//* Licensed Materials - Property of HCL Technologies
//*
//* HCL Commerce
//* HCL OneTest Performance
//*-------------------------------------------------------------------
//* The sample contained herein is provided to you "AS IS".
//*
//* It is provided by HCL Commerce to demonstrate the use of HCL OneTest
//* Performance with the "Emerald" store.
//* 
//* The sample includes a selected number of scenarios. It must be 
//* extended to match the function and use of your store.
//*
//*---------------------------------------------------------------------

package customcode;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.ibm.rational.test.lt.kernel.services.ITestExecutionServices;

public class GetNumberOfProductReturnedBySearch implements com.ibm.rational.test.lt.kernel.custom.ICustomCode2 {
	public final static String regex="<span id='searchTotalCount.+?'>([0-9].+?) matches.</span>";
	public GetNumberOfProductReturnedBySearch() {}
	public String exec(ITestExecutionServices tes, String[] args) {
		String text = args[0];
		if ( text.length() == 0 ) {
			tes.getTestLogManager().reportMessage( "Error: Search response is empty" );
			return "-1";
		}
		String result;
		Pattern pattern = Pattern.compile(regex,Pattern.DOTALL);
		Matcher matcher = pattern.matcher(text);
		
		if ( matcher.find() ) {
			result = matcher.group(1);
		}
		else {
			tes.getTestLogManager().reportMessage( "Error: Was not able to get the number of products returned" );
			return "-1";
		}
		tes.getTestLogManager().reportMessage( "Number of products returned: " + result );
		if ( Integer.valueOf( result ) == 0 ) {
			return "-1";
		}
		return result;
	}
}
