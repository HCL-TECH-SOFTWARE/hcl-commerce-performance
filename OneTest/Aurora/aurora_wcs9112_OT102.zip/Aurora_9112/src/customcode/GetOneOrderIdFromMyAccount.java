//*-------------------------------------------------------------------
//* Licensed Materials - Property of HCL Technologies
//*
//* HCL Commerce
//* HCL OneTest Performance
//*-------------------------------------------------------------------
//* The sample contained herein is provided to you "AS IS".
//*
//* It is provided by HCL Commerce to demonstrate the use of HCL OneTest
//* Performance with the "Emerald" store.
//* 
//* The sample includes a selected number of scenarios. It must be 
//* extended to match the function and use of your store.
//*
//*---------------------------------------------------------------------

package customcode;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.ibm.rational.test.lt.kernel.services.ITestExecutionServices;
public class GetOneOrderIdFromMyAccount implements com.ibm.rational.test.lt.kernel.custom.ICustomCode2 {
	public final static String regex="<div class=\"cell\" id=\"WC_OrderList_TableContent_order.+?\"WC_OrderList_Link.+?\\\">(.*?)<";
	public GetOneOrderIdFromMyAccount() {}
	public String exec(ITestExecutionServices tes, String[] args) {
		String text = args[0];
		if ( text.length() == 0 ) {
			tes.getTestLogManager().reportMessage( "Error: My Account page response is empty" );
			return "-1";
		}
		String orderIds = "";
		Pattern pattern = Pattern.compile(regex,Pattern.DOTALL);
		Matcher matcher = pattern.matcher(text);
		
		while ( matcher.find() ) {
			orderIds += matcher.group( 1 ) + ",";
			tes.getTestLogManager().reportMessage("order Id found = " + matcher.group(1));
		}
		if ( orderIds.length() == 0 ) {
			tes.getTestLogManager().reportMessage( "Error: No order Id found" );
			return "-1";
		}
		// Clean the last comma
		orderIds = orderIds.substring( 0, orderIds.length() - 1 );
		
		// Transform the string to an array 
		String [] arr_orderIds = orderIds.split( "," );
		
		// Pick a random top category
		int i = (int) Math.floor( Math.random() * arr_orderIds.length );
				
		tes.getTestLogManager().reportMessage("order Id picked = " + arr_orderIds[ i ]);
		
		return arr_orderIds[ i ];
	}
}