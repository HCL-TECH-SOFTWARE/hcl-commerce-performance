//*-------------------------------------------------------------------
//* Licensed Materials - Property of HCL Technologies
//*
//* HCL Commerce
//* HCL OneTest Performance
//*-------------------------------------------------------------------
//* The sample contained herein is provided to you "AS IS".
//*
//* It is provided by HCL Commerce to demonstrate the use of HCL OneTest
//* Performance with the "Emerald" store.
//* 
//* The sample includes a selected number of scenarios. It must be 
//* extended to match the function and use of your store.
//*
//*---------------------------------------------------------------------

package customcode;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import com.ibm.rational.test.lt.kernel.services.ITestExecutionServices;

public class GetWishlistId implements com.ibm.rational.test.lt.kernel.custom.ICustomCode2 {
	public final static String regex="javascript:shoppingListJS.addToList\\('([0-9].+?)', 'addToShoppingList'\\)";
	public GetWishlistId() {}
	public String exec(ITestExecutionServices tes, String[] args) {
		String text = args[0];
		if ( text.length() == 0 ) {
			tes.getTestLogManager().reportMessage( "Error: Wish List page response is empty" );
			return "-1";
		}
		String name, id;
		Pattern pattern = Pattern.compile(regex,Pattern.DOTALL);
		Matcher matcher = pattern.matcher(text);
		
		if ( matcher.find() ) {
			id = matcher.group( 1 );
		}
		else {
			id = "-1";
		}
		
		name = "wl_" + args[ 1 ];
		
		tes.setValue( "wish_list_id", ITestExecutionServices.STORAGE_USER, id );
		tes.setValue( "wish_list_name", ITestExecutionServices.STORAGE_USER, name );
		
		tes.getTestLogManager().reportMessage( "wish list id = " + id + ", name = " + name );
		
		return null;
	}
}
