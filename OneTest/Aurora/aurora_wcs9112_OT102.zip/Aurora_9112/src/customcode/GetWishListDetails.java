//*-------------------------------------------------------------------
//* Licensed Materials - Property of HCL Technologies
//*
//* HCL Commerce
//* HCL OneTest Performance
//*-------------------------------------------------------------------
//* The sample contained herein is provided to you "AS IS".
//*
//* It is provided by HCL Commerce to demonstrate the use of HCL OneTest
//* Performance with the "Emerald" store.
//* 
//* The sample includes a selected number of scenarios. It must be 
//* extended to match the function and use of your store.
//*
//*---------------------------------------------------------------------

package customcode;

//import java.util.regex.Matcher;
//import java.util.regex.Pattern;
import com.ibm.rational.test.lt.kernel.services.ITestExecutionServices;

public class GetWishListDetails implements com.ibm.rational.test.lt.kernel.custom.ICustomCode2 {
	public GetWishListDetails() {}
	public String exec(ITestExecutionServices tes, String[] args) {
		String text = args[0];
		if ( text.length() == 0 ) {
			tes.getTestLogManager().reportMessage( "Error: Wish List page response is empty" );
			return "-1";
		}
		String id, name;
		
		int i = text.indexOf( "MultipleWishLists.switchList" );
		int j = text.indexOf( "</select>", i );
		text = text.substring( i, j );
		
		// Search selected=
		i = text.indexOf( "selected=" );
		if ( i == -1 ) {
			id = "-1";
			name = "wl_" + args[ 1 ];
			tes.getTestLogManager().reportMessage( "No wish list found" );
		}
		else {
			i = text.indexOf( "<option value=\"" ) + "<option value=\"".length();
			j = text.indexOf( "\"", i );
			
			// Get the id 
			id = text.substring( i, j );
			tes.getTestLogManager().reportMessage( "id = " + id );
			
			i = j + "\" selected=\"selected\">".length();
			j = text.indexOf( "<", i);
			
			// Get the id 
			name = text.substring( i, j );
			tes.getTestLogManager().reportMessage( "name = " + name );
		}
		
		tes.setValue( "wish_list_id", ITestExecutionServices.STORAGE_USER, id );
		tes.setValue( "wish_list_name", ITestExecutionServices.STORAGE_USER, name );
		
		return null;
	}
}
