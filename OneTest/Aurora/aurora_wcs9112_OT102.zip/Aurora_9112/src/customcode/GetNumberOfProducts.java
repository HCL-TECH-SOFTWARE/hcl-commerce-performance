//*-------------------------------------------------------------------
//* Licensed Materials - Property of HCL Technologies
//*
//* HCL Commerce
//* HCL OneTest Performance
//*-------------------------------------------------------------------
//* The sample contained herein is provided to you "AS IS".
//*
//* It is provided by HCL Commerce to demonstrate the use of HCL OneTest
//* Performance with the "Emerald" store.
//* 
//* The sample includes a selected number of scenarios. It must be 
//* extended to match the function and use of your store.
//*
//*---------------------------------------------------------------------

package customcode;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import com.ibm.rational.test.lt.kernel.services.ITestExecutionServices;

public class GetNumberOfProducts implements com.ibm.rational.test.lt.kernel.custom.ICustomCode2 {
	public final static String regex="<span class=\"num_products\">.+? of ([0-9].+?).+?</span>";
	public GetNumberOfProducts() {}
	public String exec(ITestExecutionServices tes, String[] args) {
		String text = args[0];
		if ( text.length() == 0 ) {
			tes.getTestLogManager().reportMessage( "Error: Page response is empty" );
			return "-1";
		}
		String result = "";
		Pattern pattern = Pattern.compile( regex, Pattern.DOTALL );
		Matcher matcher = pattern.matcher( text );
		
		if ( matcher.find() ) {
			result = matcher.group(1);
		}
		if ( result.length() == 0 ) {
			tes.getTestLogManager().reportMessage( "Error: Was not able to get the number of products. The result string is empty" );
			return "-1";
		}
		// Clean the string by removing last character if it's "\n"
		if (result != null && result.length() > 0 && result.charAt(result.length() - 1) == '\n') {
			result = result.substring(0, result.length() - 1);
	    }
		
		// Doing to compare it to "12" a bit later outside the custom code
		if (Integer.parseInt(result) < 10) {
			result = '0' + result;
		}
		
		tes.getTestLogManager().reportMessage("We found " + result + " products");
		return result;
	}
}
