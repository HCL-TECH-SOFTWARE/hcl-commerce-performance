//*-------------------------------------------------------------------
//* Licensed Materials - Property of HCL Technologies
//*
//* HCL Commerce
//* HCL OneTest Performance
//*-------------------------------------------------------------------
//* The sample contained herein is provided to you "AS IS".
//*
//* It is provided by HCL Commerce to demonstrate the use of HCL OneTest
//* Performance with the "Emerald" store.
//* 
//* The sample includes a selected number of scenarios. It must be 
//* extended to match the function and use of your store.
//*
//*---------------------------------------------------------------------

package customcode;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import com.ibm.rational.test.lt.kernel.services.ITestExecutionServices;

public class GetTopCategory implements com.ibm.rational.test.lt.kernel.custom.ICustomCode2 {
	public final static String regex="<a id=\"departmentLink_[0-9]+\" href=\"(.+?)\"";
	public GetTopCategory() {}
	public String exec(ITestExecutionServices tes, String[] args) {
		String text = args[0];
		if ( text.length() == 0 ) {
			tes.getTestLogManager().reportMessage( "Error: Homepage response is empty" );
			return "-1";
		}
		
		String topcats = "";
		String result, topcat;
		String []a;
		Pattern pattern = Pattern.compile( regex,Pattern.DOTALL );
		Matcher matcher = pattern.matcher( text );
		
		while ( matcher.find() ) {
			result = matcher.group(1);
			a = result.split( "/" );
			topcat = a[ a.length - 1 ];
			topcats += topcat + ',';
		}
		if ( topcats.length() == 0 ) {
			tes.getTestLogManager().reportMessage( "Error: No top categories found" );
			return "-1";
		}
		// Clean the last comma
		topcats = topcats.substring( 0, topcats.length() - 1 );
		
		// Transform the string to an array 
		String [] arr_topcats = topcats.split( "," );
		
		// Pick a random top category
		int i = (int) Math.floor( Math.random() * arr_topcats.length );
		tes.getTestLogManager().reportMessage( "Top category number picked = " +  String.valueOf( i )  );
		
		tes.getTestLogManager().reportMessage("Top category picked = " + arr_topcats[ i ]);
		
		return arr_topcats[ i ];
	}
}
