//*-------------------------------------------------------------------
//* Licensed Materials - Property of HCL Technologies
//*
//* HCL Commerce
//* HCL OneTest Performance
//*-------------------------------------------------------------------
//* The sample contained herein is provided to you "AS IS".
//*
//* It is provided by HCL Commerce to demonstrate the use of HCL OneTest
//* Performance with the "Emerald" store.
//* 
//* The sample includes a selected number of scenarios. It must be 
//* extended to match the function and use of your store.
//*
//*---------------------------------------------------------------------

package customcode;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.ibm.rational.test.lt.kernel.services.ITestExecutionServices;

public class GetSubCategory implements com.ibm.rational.test.lt.kernel.custom.ICustomCode2 {
	public final static String regex="<a id=\"SBN_.+?href=\"(.+?)\">";
	public GetSubCategory() {}
	public String exec(ITestExecutionServices tes, String[] args) {
		String text = args[0];
		if ( text.length() == 0 ) {
			tes.getTestLogManager().reportMessage( "Error: Page response is empty" );
			return "-2";
		}
		String sub_categories = "";
		String result;
		String []a;
		Pattern pattern = Pattern.compile( regex, Pattern.DOTALL );
		Matcher matcher = pattern.matcher( text );
		
		while ( matcher.find() ) {
			result = matcher.group(1);
			a = result.split( "/" );
			sub_categories += a[ a.length - 1 ] + ',';
		}
		if ( sub_categories.length() == 0 ) {
			tes.getTestLogManager().reportMessage( "Error: No sub-categories found" );
			return "-1";
		}
		// Clean the last comma
		sub_categories = sub_categories.substring( 0, sub_categories.length() - 1 );
		
		// Transform the string to an array 
		String [] arr_sub_categories = sub_categories.split( "," );
		
		// Pick a random top category
		int i = (int) Math.floor( Math.random() * arr_sub_categories.length );
		tes.getTestLogManager().reportMessage( "Sub-category number picked = " +  String.valueOf( i )  );
		
		tes.getTestLogManager().reportMessage("Sub-category picked = " + arr_sub_categories[ i ]);
		
		return arr_sub_categories[ i ];
	}
}
