//*-------------------------------------------------------------------
//* Licensed Materials - Property of HCL Technologies
//*
//* HCL Commerce
//* HCL OneTest Performance
//*-------------------------------------------------------------------
//* The sample contained herein is provided to you "AS IS".
//*
//* It is provided by HCL Commerce to demonstrate the use of HCL OneTest
//* Performance with the "Emerald" store.
//* 
//* The sample includes a selected number of scenarios. It must be 
//* extended to match the function and use of your store.
//*
//*---------------------------------------------------------------------

package customcode;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.ibm.rational.test.lt.kernel.services.ITestExecutionServices;

public class PickProduct implements com.ibm.rational.test.lt.kernel.custom.ICustomCode2 {
	public final static String regex="<div class=\"product_name\">.+?href=\"(.+?)\"";
	public PickProduct() {}
	public String exec(ITestExecutionServices tes, String[] args) {
		String text = args[0];
		if ( text.length() == 0 ) {
			tes.getTestLogManager().reportMessage( "Error: Page response is empty" );
			return "-2";
		}
		String products = "";
		String result;
		String []a;
		Pattern pattern = Pattern.compile( regex, Pattern.DOTALL );
		Matcher matcher = pattern.matcher( text );
		
		while ( matcher.find() ) {
			result = matcher.group(1);
			a = result.split( "/" );
			products += a[ a.length - 1 ] + ',';
		}
		if ( products.length() == 0 ) {
			tes.getTestLogManager().reportMessage( "Error: No products found" );
			return "-1";
		}
		// Clean the last comma
		products = products.substring( 0, products.length() - 1 );
		
		// Transform the string to an array 
		String [] arr_products = products.split( "," );
		
		// Pick a random top category
		int i = (int) Math.floor( Math.random() * arr_products.length );
		tes.getTestLogManager().reportMessage( "Found " + String.valueOf( arr_products.length ) + " Products. Picked # " + String.valueOf( i )  );
		
		tes.getTestLogManager().reportMessage("Product name picked = " + arr_products[ i ]);
		
		return arr_products[ i ];
	}
}