//*-------------------------------------------------------------------
//* Licensed Materials - Property of HCL Technologies
//*
//* HCL Commerce
//* HCL OneTest Performance
//*-------------------------------------------------------------------
//* The sample contained herein is provided to you "AS IS".
//*
//* It is provided by HCL Commerce to demonstrate the use of HCL OneTest
//* Performance with the "Emerald" store.
//* 
//* The sample includes a selected number of scenarios. It must be 
//* extended to match the function and use of your store.
//*
//*---------------------------------------------------------------------

package customcode;

import java.util.Random;

import com.ibm.rational.test.lt.kernel.services.ITestExecutionServices;

public class GenerateRandomAddress implements com.ibm.rational.test.lt.kernel.custom.ICustomCode2 {
	public GenerateRandomAddress() {}
	String alphanumeric = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
	public String exec(ITestExecutionServices tes, String[] args) {
		int min_length = 4, max_length = 10;
		Random rand = new Random();
		int length;		
		String lastname = "", firstname = "", address1 = "", nickname = "";
		
		// Build nickname
		length = rand.nextInt( ( max_length - min_length ) + 1 ) + min_length;
	    while (nickname.length() < length) { 
            int index = (int) (rand.nextFloat() * alphanumeric.length());
            nickname += alphanumeric.charAt(index);
        }
	    
	    // Build firstname
	 	length = rand.nextInt( ( max_length - min_length ) + 1 ) + min_length;
	 	while (firstname.length() < length) { 
	 		int index = (int) (rand.nextFloat() * alphanumeric.length());
	 		firstname += alphanumeric.charAt(index);
 	    }
	    
	    // Build lastname
	 	length = rand.nextInt( ( max_length - min_length ) + 1 ) + min_length;
	 	while (lastname.length() < length) { 
	 		int index = (int) (rand.nextFloat() * alphanumeric.length());
	 		lastname += alphanumeric.charAt(index);
 	    }

	 	// Build address1 - firstname + lastname + nickname
	 	address1 = firstname + " " + lastname + " " + nickname;
	 	
	 	tes.getTestLogManager().reportMessage( "nickname = " + nickname );
		tes.setValue( "nickname", ITestExecutionServices.STORAGE_USER, nickname );
	 	
		tes.getTestLogManager().reportMessage( "firstname = " + firstname );
		tes.setValue( "firstname", ITestExecutionServices.STORAGE_USER, firstname );
		
		tes.getTestLogManager().reportMessage( "lastname = " + lastname );
		tes.setValue( "lastname", ITestExecutionServices.STORAGE_USER, lastname );
		
		tes.getTestLogManager().reportMessage( "address1 = " + address1 );
		tes.setValue( "address1", ITestExecutionServices.STORAGE_USER, address1 );

		return null;
	}
}
