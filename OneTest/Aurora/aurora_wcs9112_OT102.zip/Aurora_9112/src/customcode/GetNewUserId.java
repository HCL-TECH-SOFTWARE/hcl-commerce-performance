//*-------------------------------------------------------------------
//* Licensed Materials - Property of HCL Technologies
//*
//* HCL Commerce
//* HCL OneTest Performance
//*-------------------------------------------------------------------
//* The sample contained herein is provided to you "AS IS".
//*
//* It is provided by HCL Commerce to demonstrate the use of HCL OneTest
//* Performance with the "Emerald" store.
//* 
//* The sample includes a selected number of scenarios. It must be 
//* extended to match the function and use of your store.
//*
//*---------------------------------------------------------------------

package customcode;

import com.ibm.rational.test.lt.kernel.services.ITestExecutionServices;

public class GetNewUserId implements com.ibm.rational.test.lt.kernel.custom.ICustomCode2 {
	public GetNewUserId() {}
	public String exec(ITestExecutionServices tes, String[] args) {
		int user_id  = Integer.valueOf( args[ 0 ] );
		int user_max = Integer.valueOf( args[ 1 ] );
		int user_min = Integer.valueOf( args[ 3 ] );
		
		if ( user_id == user_max + user_min ) {
			return "-1";
		}
		String user = args[ 2 ] + Integer.toString( user_id );
		
		tes.getTestLogManager().reportMessage( "New userid = " + user );
		
		user_id++;
		tes.setValue( "user_id", ITestExecutionServices.STORAGE_USER, Integer.toString( user_id ) );
		
		return user;
	}
}
