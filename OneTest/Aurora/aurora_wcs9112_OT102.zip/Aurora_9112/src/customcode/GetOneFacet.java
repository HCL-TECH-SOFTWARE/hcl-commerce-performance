//*-------------------------------------------------------------------
//* Licensed Materials - Property of HCL Technologies
//*
//* HCL Commerce
//* HCL OneTest Performance
//*-------------------------------------------------------------------
//* The sample contained herein is provided to you "AS IS".
//*
//* It is provided by HCL Commerce to demonstrate the use of HCL OneTest
//* Performance with the "Emerald" store.
//* 
//* The sample includes a selected number of scenarios. It must be 
//* extended to match the function and use of your store.
//*
//*---------------------------------------------------------------------

package customcode;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.ibm.rational.test.lt.kernel.services.ITestExecutionServices;

public class GetOneFacet implements com.ibm.rational.test.lt.kernel.custom.ICustomCode2 {
	public final static String regex="<a id=\"SBN_.+?href=\"(.+?)\">.+?<div class=\"facetCountContainer\">";
	public GetOneFacet() {}
	public String exec(ITestExecutionServices tes, String[] args) {
		String text = args[0];
		String link;
		String links = "";
		int i;
		Pattern pattern = Pattern.compile(regex,Pattern.DOTALL);
		Matcher matcher = pattern.matcher(text);
		
		while ( matcher.find() ) {
			link = matcher.group( 1 );
			i = link.indexOf( "/wcs/shop" );
			if ( i != -1 ) {
				link = link.substring( i );
			}
			else {
				tes.getTestLogManager().reportMessage( "Error: String /wcs/shop was not found in facet: " + link );
				return "-1";
			}
			links += link + ",";
		}
		// Clean the last '
		links = links.substring( 0, links.length() - 1 );
		
		String [] arr_links = links.split( "," );
		// Pick a random top category
		i = (int) Math.floor( Math.random() * arr_links.length );
		tes.getTestLogManager().reportMessage("Facet picked = " + arr_links[ i ]);
		return arr_links[ i ];
	}
}
