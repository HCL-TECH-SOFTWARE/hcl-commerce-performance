//*-------------------------------------------------------------------
//* Licensed Materials - Property of HCL Technologies
//*
//* HCL Commerce
//* HCL OneTest Performance
//*-------------------------------------------------------------------
//* The sample contained herein is provided to you "AS IS".
//*
//* It is provided by HCL Commerce to demonstrate the use of HCL OneTest
//* Performance with the "Emerald" store.
//* 
//* The sample includes a selected number of scenarios. It must be 
//* extended to match the function and use of your store.
//*
//*---------------------------------------------------------------------

package customcode;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import com.ibm.rational.test.lt.kernel.services.ITestExecutionServices;

public class GetAmount implements com.ibm.rational.test.lt.kernel.custom.ICustomCode2 {
	public GetAmount() {}
	public final static String regex="total_figures breadcrumb_current\" id=\"WC_SingleShipmentOrderTotalsSummary_td_[0-9].+?\">\\$([0-9].+?)<";
	public String exec(ITestExecutionServices tes, String[] args) {
		String text = args[0];
		if ( text.length() == 0 ) {
			tes.getTestLogManager().reportMessage( "Error: Cart response is empty" );
			return "-1";
		}
		
		String amount = "";
		Pattern pattern = Pattern.compile( regex,Pattern.DOTALL );
		Matcher matcher = pattern.matcher( text );
		
		if ( matcher.find() ) {
			amount = matcher.group(1).replace(",", "");
		}
	
		if ( amount.length() == 0 ) {
			tes.getTestLogManager().reportMessage( "Error: No amount was found" );
			return "-1";
		}
		
		tes.getTestLogManager().reportMessage("Amount picked = " + amount);
		
		return amount;
	}
}
