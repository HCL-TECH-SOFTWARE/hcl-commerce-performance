//*-------------------------------------------------------------------
//* Licensed Materials - Property of HCL Technologies
//*
//* HCL Commerce
//* HCL OneTest Performance
//*-------------------------------------------------------------------
//* The sample contained herein is provided to you "AS IS".
//*
//* It is provided by HCL Commerce to demonstrate the use of HCL OneTest
//* Performance with the "Emerald" store.
//* 
//* The sample includes a selected number of scenarios. It must be 
//* extended to match the function and use of your store.
//*
//*---------------------------------------------------------------------

package customcode;

import com.ibm.rational.test.lt.kernel.services.ITestExecutionServices;

public class GetAddressId implements com.ibm.rational.test.lt.kernel.custom.ICustomCode2 {
	public GetAddressId() {}
	public String exec(ITestExecutionServices tes, String[] args) {
		String text = args[0];
		if ( text.length() == 0 ) {
			tes.getTestLogManager().reportMessage( "Error: OrderShippingBillingView page response is empty" );
			return "-1";
		}
		int i = text.indexOf( "id=\"selectedAddressId_1\"" );
		if ( i == -1 ) {
			tes.getTestLogManager().reportMessage( "Error: selectedAddressId_1 string was not found in OrderShippingBillingView page" );
			return "-1";
		}
		i -= 2;
		int j = text.lastIndexOf( "value=\"", i ) + "value=\"".length();
		
		String id = text.substring( j, i );
		
		if ( id.length() == 0 ) {
			i = text.indexOf( "console.debug(\"addressId= \" + \"" );
			if ( i == -1 ) {
				tes.getTestLogManager().reportMessage( "Error1: console.debug(\"addressId= string was not found in OrderShippingBillingView page" );
				return "-1";
			}
			i += "console.debug(\"addressId= \" + \"".length();
			j = text.indexOf( "\");", i );
			if ( j == -1 ) {
				tes.getTestLogManager().reportMessage( "Error2: console.debug(\"addressId= string was not found in OrderShippingBillingView page" );
				return "-1";
			}
			id = text.substring( i, j );
		}
		
		tes.getTestLogManager().reportMessage( "id = " + id );
		return id;
	}
}
